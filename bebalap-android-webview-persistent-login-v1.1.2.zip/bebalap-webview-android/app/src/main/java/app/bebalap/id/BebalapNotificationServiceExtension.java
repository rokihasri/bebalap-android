package app.bebalap.id;

import androidx.annotation.Keep;
import androidx.core.content.ContextCompat;

import com.onesignal.notifications.IDisplayableMutableNotification;
import com.onesignal.notifications.INotificationReceivedEvent;
import com.onesignal.notifications.INotificationServiceExtension;

@Keep
public class BebalapNotificationServiceExtension implements INotificationServiceExtension {
    @Override
    public void onNotificationReceived(INotificationReceivedEvent event) {
        IDisplayableMutableNotification notification = event.getNotification();
        notification.setExtender(builder -> builder
                .setSmallIcon(R.drawable.ic_stat_bebalap)
                .setColor(ContextCompat.getColor(event.getContext(), R.color.bebalap_blue)));
    }
}
