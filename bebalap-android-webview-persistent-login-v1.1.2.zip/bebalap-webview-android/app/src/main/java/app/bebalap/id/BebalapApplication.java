package app.bebalap.id;

import android.app.Application;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

import androidx.annotation.Nullable;

import com.onesignal.OneSignal;
import com.onesignal.debug.LogLevel;
import com.onesignal.notifications.INotificationClickEvent;
import com.onesignal.notifications.INotificationClickListener;

import org.json.JSONObject;

public class BebalapApplication extends Application {
    private static BebalapApplication instance;

    public static BebalapApplication getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        if (BuildConfig.DEBUG) {
            OneSignal.getDebug().setLogLevel(LogLevel.VERBOSE);
        }

        OneSignal.initWithContext(this, BuildConfig.ONESIGNAL_APP_ID);

        // Keep the native push identity alive independently from the WebView/Laravel
        // session. It is removed only when MainActivity receives an explicit logout.
        String rememberedExternalId = getSharedPreferences("bebalap_native", MODE_PRIVATE)
                .getString("onesignal_external_id", null);
        if (!TextUtils.isEmpty(rememberedExternalId)
                && rememberedExternalId.matches("^bebalap_user_[0-9]+$")) {
            OneSignal.login(rememberedExternalId);
        }

        OneSignal.getNotifications().addClickListener(new INotificationClickListener() {
            @Override
            public void onClick(INotificationClickEvent event) {
                String target = event.getNotification().getLaunchURL();
                JSONObject data = event.getNotification().getAdditionalData();

                if (TextUtils.isEmpty(target) && data != null) {
                    target = firstNonEmpty(
                            data.optString("url", null),
                            data.optString("link", null),
                            data.optString("target_url", null),
                            data.optString("route", null)
                    );
                }

                routeNotificationTarget(target);
            }
        });
    }

    private void routeNotificationTarget(@Nullable String rawTarget) {
        String target = MainActivity.normalizeTargetUrl(rawTarget);
        Uri uri = Uri.parse(target);

        if (MainActivity.isInternalBebalapUri(uri)) {
            Intent intent = new Intent(this, MainActivity.class)
                    .putExtra(MainActivity.EXTRA_TARGET_URL, target)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TOP
                            | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            return;
        }

        try {
            Intent external = new Intent(Intent.ACTION_VIEW, uri)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(external);
        } catch (Exception ignored) {
            Intent fallback = new Intent(this, MainActivity.class)
                    .putExtra(MainActivity.EXTRA_TARGET_URL, BuildConfig.BASE_URL)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TOP
                            | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(fallback);
        }
    }

    @Nullable
    private static String firstNonEmpty(@Nullable String... values) {
        if (values == null) return null;
        for (String value : values) {
            if (!TextUtils.isEmpty(value) && !"null".equalsIgnoreCase(value)) {
                return value;
            }
        }
        return null;
    }
}
