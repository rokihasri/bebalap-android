package app.bebalap.id;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.http.SslError;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.splashscreen.SplashScreen;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import com.onesignal.Continue;
import com.onesignal.OneSignal;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    public static final String EXTRA_TARGET_URL = "bebalap_target_url";

    private static final long SPLASH_DURATION_MS = 2_000L;
    private static final int REQUEST_FILE_CHOOSER = 4001;
    private static final int REQUEST_WEB_PERMISSIONS = 4002;
    private static final int REQUEST_GEOLOCATION = 4003;
    private static final int REQUEST_LEGACY_DOWNLOAD_STORAGE = 4004;
    private static final int REQUEST_CAMERA_FOR_FILE_CHOOSER = 4005;

    private static final String PREFS = "bebalap_native";
    private static final String PREF_NOTIFICATION_ASKED = "notification_permission_asked";
    private static final String PREF_EXTERNAL_ID = "onesignal_external_id";

    private static final String BASE_HOST = "bebalap.thegreatmonolith.com";
    private static final Pattern EXTERNAL_ID_PATTERN = Pattern.compile("^bebalap_user_[0-9]+$");
    private static final Set<String> INTERNAL_ORIGINS = new HashSet<>(Arrays.asList(
            "https://bebalap.thegreatmonolith.com"
    ));

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraOutputUri;
    private Intent pendingFileChooserIntent;
    private PermissionRequest pendingWebPermissionRequest;
    private String pendingGeolocationOrigin;
    private GeolocationPermissions.Callback pendingGeolocationCallback;
    private String pendingDownloadUrl;
    private String pendingDownloadUserAgent;
    private String pendingDownloadContentDisposition;
    private String pendingDownloadMimeType;
    private boolean showingOfflinePage = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        final long splashStartedAt = SystemClock.uptimeMillis();
        SplashScreen splashScreen = SplashScreen.installSplashScreen(this);
        splashScreen.setKeepOnScreenCondition(
                () -> SystemClock.uptimeMillis() - splashStartedAt < SPLASH_DURATION_MS
        );

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configureFullscreen();

        webView = findViewById(R.id.webview);
        configureWebView();
        configureNativeBridge();
        configureDocumentStartScript();

        String initialUrl = extractTargetFromIntent(getIntent());
        if (savedInstanceState == null) {
            webView.loadUrl(initialUrl);
        } else {
            webView.restoreState(savedInstanceState);
        }

        webView.postDelayed(this::requestNotificationPermissionOnce, SPLASH_DURATION_MS + 450L);
    }

    private void configureFullscreen() {
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
            getWindow().setStatusBarContrastEnforced(false);
        }
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        hideSystemBars();
    }

    private void hideSystemBars() {
        WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        );

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        webView.setBackgroundColor(Color.WHITE);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setUserAgentString(settings.getUserAgentString() + " BeBalapAndroid/1.1");

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new BebalapWebViewClient());
        webView.setWebChromeClient(new BebalapWebChromeClient());
        webView.setDownloadListener(new BebalapDownloadListener());
    }

    private void configureNativeBridge() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            return;
        }

        WebViewCompat.addWebMessageListener(
                webView,
                "BebalapNative",
                INTERNAL_ORIGINS,
                new WebViewCompat.WebMessageListener() {
                    @Override
                    public void onPostMessage(@NonNull WebView view,
                                              @NonNull WebMessageCompat message,
                                              @NonNull Uri sourceOrigin,
                                              boolean isMainFrame,
                                              @NonNull JavaScriptReplyProxy replyProxy) {
                        if (!isMainFrame) return;
                        if (!"https".equalsIgnoreCase(sourceOrigin.getScheme())
                                || !BASE_HOST.equalsIgnoreCase(sourceOrigin.getHost())) {
                            return;
                        }
                        String payload = message.getData();
                        handleNativeMessage(payload);
                    }
                }
        );
    }

    private void configureDocumentStartScript() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            return;
        }

        String script = "(function(){"
                + "try{"
                + "var style=document.createElement('style');"
                + "style.textContent='[data-pwa-prompts],[data-pwa-ios-guide],#pwa-install-badge,#notification-permission-badge{display:none!important}';"
                + "(document.head||document.documentElement).appendChild(style);"
                + "var post=function(p){try{if(window.BebalapNative&&BebalapNative.postMessage){BebalapNative.postMessage(JSON.stringify(p));}}catch(e){}};"
                + "var sendIdentity=function(id){if(id)post({type:\"identity\",externalId:id});};"
                + "var explicitLogout=function(){try{return ('; '+(document.cookie||'')+';').indexOf('; bebalap_explicit_logout=1;')!==-1;}catch(e){return false;}};"
                + "if(explicitLogout())post({type:\"explicit_logout\"});"
                + "window.addEventListener('bebalap:push-state',function(e){var d=e&&e.detail||{};sendIdentity(d.expectedExternalId||null);});"
                + "var sync=function(){try{if(explicitLogout()){post({type:\"explicit_logout\"});return;}var s=window.BebalapPush&&window.BebalapPush.state?window.BebalapPush.state():null;if(s&&s.expectedExternalId)sendIdentity(s.expectedExternalId);}catch(e){}};"
                + "document.addEventListener('DOMContentLoaded',function(){setTimeout(sync,100);setTimeout(sync,900);setTimeout(sync,2500);});"
                + "}catch(e){}"
                + "})();";

        WebViewCompat.addDocumentStartJavaScript(webView, script, INTERNAL_ORIGINS);
    }

    private void handleNativeMessage(@Nullable String payload) {
        if (TextUtils.isEmpty(payload)) return;
        try {
            JSONObject object = new JSONObject(payload);
            String type = object.optString("type");
            if ("explicit_logout".equals(type)) {
                clearOneSignalIdentity();
                return;
            }
            if (!"identity".equals(type)) return;
            String externalId = object.isNull("externalId")
                    ? null
                    : object.optString("externalId", null);
            syncOneSignalIdentity(externalId);
        } catch (Exception ignored) {
        }
    }

    private void syncOneSignalIdentity(@Nullable String externalId) {
        String current = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString(PREF_EXTERNAL_ID, null);

        // A guest/null web state can happen when a Laravel session expires or while
        // the WebView is restoring. Do NOT detach native push identity here. Native
        // OneSignal is only logged out after an explicit user logout signal.
        if (TextUtils.isEmpty(externalId)) {
            return;
        }

        if (!EXTERNAL_ID_PATTERN.matcher(externalId).matches()) {
            return;
        }

        if (externalId.equals(current)) {
            return;
        }

        OneSignal.login(externalId);
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit().putString(PREF_EXTERNAL_ID, externalId).apply();
    }

    private void clearOneSignalIdentity() {
        String current = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString(PREF_EXTERNAL_ID, null);
        if (!TextUtils.isEmpty(current)) {
            OneSignal.logout();
        }
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit().remove(PREF_EXTERNAL_ID).apply();
    }

    private void syncIdentityFallback(WebView view) {
        String script = "(function(){try{"
                + "if(('; '+(document.cookie||'')+';').indexOf('; bebalap_explicit_logout=1;')!==-1)return '__EXPLICIT_LOGOUT__';"
                + "if(window.BebalapPush&&window.BebalapPush.state){var x=window.BebalapPush.state();if(x&&x.expectedExternalId)return x.expectedExternalId;}"
                + "var ss=document.scripts||[];for(var i=0;i<ss.length;i++){var t=ss[i].textContent||'';if(/explicitPushLogout\\s*=\\s*true/.test(t))return '__EXPLICIT_LOGOUT__';var m=t.match(/expectedExternalId\\s*=\\s*[\"'](bebalap_user_[0-9]+)[\"']/);if(m)return m[1];}"
                + "}catch(e){}return '';})()";
        view.evaluateJavascript(script, value -> {
            if (value == null) return;
            String cleaned = value.replace("\"", "").trim();
            if ("__EXPLICIT_LOGOUT__".equals(cleaned)) clearOneSignalIdentity();
            else if (EXTERNAL_ID_PATTERN.matcher(cleaned).matches()) syncOneSignalIdentity(cleaned);
        });
    }

    private void requestNotificationPermissionOnce() {
        boolean asked = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(PREF_NOTIFICATION_ASKED, false);
        if (asked) return;

        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit().putBoolean(PREF_NOTIFICATION_ASKED, true).apply();

        OneSignal.getNotifications().requestPermission(false, Continue.none());
    }

    private class BebalapWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleNavigation(request.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleNavigation(Uri.parse(url));
        }

        @Override
        public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            showingOfflinePage = url != null && url.startsWith("file:///android_asset/offline.html");

            // v456 web sets this short-lived cookie only when the user presses Logout.
            // Reading it here makes explicit logout reliable even on WebView versions
            // that do not support document-start JavaScript.
            if (url != null && isInternalBebalapUri(Uri.parse(url))) {
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null && cookies.contains("bebalap_explicit_logout=1")) {
                    clearOneSignalIdentity();
                }
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            hideSystemBars();
            if (isInternalBebalapUri(Uri.parse(url))) {
                // Fallback for old WebView versions without document-start scripting.
                view.evaluateJavascript(
                        "(function(){try{var e=document.querySelector('[data-pwa-prompts]');if(e)e.style.display='none';var i=document.querySelector('[data-pwa-ios-guide]');if(i)i.style.display='none';}catch(e){}})();",
                        null
                );
                syncIdentityFallback(view);
                // Persist Laravel session/remember/device cookies immediately. Android WebView
                // may otherwise keep recent Set-Cookie changes only in memory until the process
                // is killed, which makes the next app launch look logged out.
                CookieManager.getInstance().flush();
            }
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            if (request.isForMainFrame()) {
                showOfflinePage();
            }
        }

        @Override
        public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
            super.onReceivedHttpError(view, request, errorResponse);
            // Keep server-side Laravel error pages visible; only network failures use native offline page.
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.cancel();
            Toast.makeText(MainActivity.this, "Koneksi aman gagal diverifikasi.", Toast.LENGTH_SHORT).show();
        }
    }

    private class BebalapWebChromeClient extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView webView,
                                         ValueCallback<Uri[]> filePathCallback,
                                         FileChooserParams fileChooserParams) {
            if (MainActivity.this.filePathCallback != null) {
                MainActivity.this.filePathCallback.onReceiveValue(null);
            }
            MainActivity.this.filePathCallback = filePathCallback;

            Intent chooser = buildFileChooserIntent(fileChooserParams);
            Parcelable[] cameraOptions = chooser.getParcelableArrayExtra(Intent.EXTRA_INITIAL_INTENTS);
            boolean wantsCamera = cameraOptions != null && cameraOptions.length > 0;

            if (wantsCamera
                    && ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                pendingFileChooserIntent = chooser;
                ActivityCompat.requestPermissions(
                        MainActivity.this,
                        new String[]{Manifest.permission.CAMERA},
                        REQUEST_CAMERA_FOR_FILE_CHOOSER
                );
                return true;
            }

            launchFileChooser(chooser);
            return true;
        }

        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            Uri origin = request.getOrigin();
            if (origin == null || !isInternalBebalapUri(origin)) {
                request.deny();
                return;
            }

            List<String> runtimePermissions = new ArrayList<>();
            List<String> requestedWebResources = Arrays.asList(request.getResources());

            if (requestedWebResources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                    && ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                runtimePermissions.add(Manifest.permission.CAMERA);
            }

            if (requestedWebResources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    && ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                runtimePermissions.add(Manifest.permission.RECORD_AUDIO);
            }

            if (runtimePermissions.isEmpty()) {
                String[] grantable = filterGrantableWebResources(request);
                if (grantable.length > 0) request.grant(grantable);
                else request.deny();
            } else {
                pendingWebPermissionRequest = request;
                ActivityCompat.requestPermissions(
                        MainActivity.this,
                        runtimePermissions.toArray(new String[0]),
                        REQUEST_WEB_PERMISSIONS
                );
            }
        }

        @Override
        public void onPermissionRequestCanceled(PermissionRequest request) {
            if (pendingWebPermissionRequest == request) {
                pendingWebPermissionRequest = null;
            }
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
            Uri uri = Uri.parse(origin);
            if (!isInternalBebalapUri(uri)) {
                callback.invoke(origin, false, false);
                return;
            }

            boolean fine = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED;
            boolean coarse = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED;

            if (fine || coarse) {
                callback.invoke(origin, true, false);
                return;
            }

            pendingGeolocationOrigin = origin;
            pendingGeolocationCallback = callback;
            ActivityCompat.requestPermissions(
                    MainActivity.this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    REQUEST_GEOLOCATION
            );
        }
    }

    private String[] filterGrantableWebResources(PermissionRequest request) {
        List<String> grantable = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                    && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_GRANTED) {
                grantable.add(resource);
            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                    && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED) {
                grantable.add(resource);
            } else if (PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID.equals(resource)) {
                grantable.add(resource);
            }
        }
        return grantable.toArray(new String[0]);
    }

    private Intent buildFileChooserIntent(WebChromeClient.FileChooserParams params) {
        Intent contentIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
        contentIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                params != null && params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE);

        String[] accepts = params == null ? new String[0] : params.getAcceptTypes();
        List<String> cleanedAccepts = new ArrayList<>();
        if (accepts != null) {
            for (String accept : accepts) {
                if (TextUtils.isEmpty(accept)) continue;
                for (String part : accept.split(",")) {
                    String mime = part == null ? "" : part.trim();
                    if (!TextUtils.isEmpty(mime)) cleanedAccepts.add(mime);
                }
            }
        }

        if (cleanedAccepts.isEmpty()) {
            contentIntent.setType("*/*");
        } else if (cleanedAccepts.size() == 1) {
            contentIntent.setType(cleanedAccepts.get(0));
        } else {
            contentIntent.setType("*/*");
            contentIntent.putExtra(Intent.EXTRA_MIME_TYPES, cleanedAccepts.toArray(new String[0]));
        }

        ArrayList<Intent> initialIntents = new ArrayList<>();
        boolean acceptsImages = cleanedAccepts.isEmpty() || containsMimePrefix(cleanedAccepts, "image/") || cleanedAccepts.contains("*/*");
        boolean acceptsVideo = cleanedAccepts.isEmpty() || containsMimePrefix(cleanedAccepts, "video/") || cleanedAccepts.contains("*/*");

        if (acceptsImages) {
            Intent imageCapture = createImageCaptureIntent();
            if (imageCapture != null) initialIntents.add(imageCapture);
        }
        if (acceptsVideo) {
            Intent videoCapture = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
            if (videoCapture.resolveActivity(getPackageManager()) != null) {
                initialIntents.add(videoCapture);
            }
        }

        Intent chooser = Intent.createChooser(contentIntent, "Pilih File");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, initialIntents.toArray(new Parcelable[0]));
        return chooser;
    }

    @Nullable
    private Intent createImageCaptureIntent() {
        Intent capture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (capture.resolveActivity(getPackageManager()) == null) return null;

        try {
            File cameraDir = new File(getCacheDir(), "camera");
            if (!cameraDir.exists() && !cameraDir.mkdirs()) return null;
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File image = File.createTempFile("bebalap_" + stamp + "_", ".jpg", cameraDir);
            cameraOutputUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    image
            );
            capture.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
            capture.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return capture;
        } catch (IOException e) {
            return null;
        }
    }

    private boolean containsMimePrefix(List<String> mimeTypes, String prefix) {
        for (String mime : mimeTypes) {
            if (mime != null && mime.startsWith(prefix)) return true;
        }
        return false;
    }

    private void launchFileChooser(Intent chooser) {
        try {
            startActivityForResult(chooser, REQUEST_FILE_CHOOSER);
        } catch (Exception e) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
                filePathCallback = null;
            }
            Toast.makeText(this, "Tidak ada aplikasi untuk memilih file.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_FILE_CHOOSER || filePathCallback == null) return;

        Uri[] results = null;
        if (resultCode == RESULT_OK) {
            if (data == null || (data.getData() == null && data.getClipData() == null)) {
                if (cameraOutputUri != null) {
                    results = new Uri[]{cameraOutputUri};
                }
            } else if (data.getClipData() != null) {
                ClipData clipData = data.getClipData();
                results = new Uri[clipData.getItemCount()];
                for (int i = 0; i < clipData.getItemCount(); i++) {
                    results[i] = clipData.getItemAt(i).getUri();
                }
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }

        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
        cameraOutputUri = null;
    }

    private class BebalapDownloadListener implements DownloadListener {
        @Override
        public void onDownloadStart(String url,
                                    String userAgent,
                                    String contentDisposition,
                                    String mimeType,
                                    long contentLength) {
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                    && ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                pendingDownloadUrl = url;
                pendingDownloadUserAgent = userAgent;
                pendingDownloadContentDisposition = contentDisposition;
                pendingDownloadMimeType = mimeType;
                ActivityCompat.requestPermissions(
                        MainActivity.this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQUEST_LEGACY_DOWNLOAD_STORAGE
                );
                return;
            }
            enqueueDownload(url, userAgent, contentDisposition, mimeType);
        }
    }

    private void enqueueDownload(String url, String userAgent, String contentDisposition, String mimeType) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            request.addRequestHeader("User-Agent", userAgent == null ? webView.getSettings().getUserAgentString() : userAgent);

            String cookies = CookieManager.getInstance().getCookie(url);
            if (!TextUtils.isEmpty(cookies)) request.addRequestHeader("Cookie", cookies);

            String fileName = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType);
            request.setTitle(fileName);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);

            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            manager.enqueue(request);
            Toast.makeText(this, "Download dimulai.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            openExternal(Uri.parse(url));
        }
    }

    private boolean handleNavigation(@Nullable Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme();

        if (isInternalBebalapUri(uri)) {
            return false;
        }

        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            openExternal(uri);
            return true;
        }

        if ("intent".equalsIgnoreCase(scheme)) {
            try {
                Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else if (!TextUtils.isEmpty(intent.getPackage())) {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("market://details?id=" + intent.getPackage())));
                }
            } catch (Exception ignored) {
            }
            return true;
        }

        if (Arrays.asList("tel", "mailto", "sms", "smsto", "geo", "market", "whatsapp").contains(scheme)) {
            openExternal(uri);
            return true;
        }

        try {
            openExternal(uri);
            return true;
        } catch (Exception ignored) {
            return true;
        }
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) {
            Toast.makeText(this, "Tidak ada aplikasi yang dapat membuka tautan ini.", Toast.LENGTH_SHORT).show();
        }
    }

    private void showOfflinePage() {
        if (showingOfflinePage) return;
        showingOfflinePage = true;
        webView.loadUrl("file:///android_asset/offline.html");
    }

    private String extractTargetFromIntent(@Nullable Intent intent) {
        if (intent == null) return BuildConfig.BASE_URL;

        String extra = intent.getStringExtra(EXTRA_TARGET_URL);
        if (!TextUtils.isEmpty(extra)) return normalizeTargetUrl(extra);

        Uri data = intent.getData();
        if (isInternalBebalapUri(data)) return data.toString();

        return BuildConfig.BASE_URL;
    }

    public static String normalizeTargetUrl(@Nullable String raw) {
        if (TextUtils.isEmpty(raw) || "null".equalsIgnoreCase(raw)) {
            return BuildConfig.BASE_URL;
        }
        String trimmed = raw.trim();
        if (trimmed.startsWith("/")) {
            return BuildConfig.BASE_URL + trimmed;
        }
        if (!trimmed.contains("://") && !trimmed.startsWith("mailto:") && !trimmed.startsWith("tel:")) {
            return BuildConfig.BASE_URL + "/" + trimmed.replaceFirst("^/+", "");
        }
        return trimmed;
    }

    public static boolean isInternalBebalapUri(@Nullable Uri uri) {
        return uri != null
                && "https".equalsIgnoreCase(uri.getScheme())
                && BASE_HOST.equalsIgnoreCase(uri.getHost());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String target = extractTargetFromIntent(intent);
        if (webView != null && isInternalBebalapUri(Uri.parse(target))) {
            showingOfflinePage = false;
            webView.loadUrl(target);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_WEB_PERMISSIONS) {
            if (pendingWebPermissionRequest != null) {
                String[] grantable = filterGrantableWebResources(pendingWebPermissionRequest);
                if (grantable.length > 0) pendingWebPermissionRequest.grant(grantable);
                else pendingWebPermissionRequest.deny();
                pendingWebPermissionRequest = null;
            }
            return;
        }

        if (requestCode == REQUEST_GEOLOCATION) {
            boolean granted = false;
            for (int result : grantResults) {
                if (result == PackageManager.PERMISSION_GRANTED) {
                    granted = true;
                    break;
                }
            }
            if (pendingGeolocationCallback != null && pendingGeolocationOrigin != null) {
                pendingGeolocationCallback.invoke(pendingGeolocationOrigin, granted, false);
            }
            pendingGeolocationCallback = null;
            pendingGeolocationOrigin = null;
            return;
        }

        if (requestCode == REQUEST_CAMERA_FOR_FILE_CHOOSER) {
            if (pendingFileChooserIntent != null) {
                boolean cameraGranted = grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED;
                if (!cameraGranted) {
                    // File/gallery upload must remain usable even when camera permission is denied.
                    pendingFileChooserIntent.putExtra(
                            Intent.EXTRA_INITIAL_INTENTS,
                            new Parcelable[0]
                    );
                    cameraOutputUri = null;
                }
                launchFileChooser(pendingFileChooserIntent);
                pendingFileChooserIntent = null;
            }
            return;
        }

        if (requestCode == REQUEST_LEGACY_DOWNLOAD_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    && pendingDownloadUrl != null) {
                enqueueDownload(
                        pendingDownloadUrl,
                        pendingDownloadUserAgent,
                        pendingDownloadContentDisposition,
                        pendingDownloadMimeType
                );
            }
            pendingDownloadUrl = null;
            pendingDownloadUserAgent = null;
            pendingDownloadContentDisposition = null;
            pendingDownloadMimeType = null;
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        hideSystemBars();
    }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onStop() {
        CookieManager.getInstance().flush();
        super.onStop();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override
    public void onBackPressed() {
        if (showingOfflinePage) {
            showingOfflinePage = false;
            webView.loadUrl(BuildConfig.BASE_URL);
        } else if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        CookieManager.getInstance().flush();
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
