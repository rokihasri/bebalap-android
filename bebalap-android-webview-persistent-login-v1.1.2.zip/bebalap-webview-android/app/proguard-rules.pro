# OneSignal service extension is discovered by fully-qualified class name from AndroidManifest.
# @Keep is also present on the class; this explicit rule keeps release/R8 behavior deterministic.
-keep class app.bebalap.id.BebalapNotificationServiceExtension { *; }
