#!/usr/bin/env bash
set -euo pipefail

OUT="${1:-bebalap-upload.jks}"
ALIAS="${BEBALAP_KEY_ALIAS:-bebalap}"
STORE_PASS="${BEBALAP_KEYSTORE_PASSWORD:-}"
KEY_PASS="${BEBALAP_KEY_PASSWORD:-$STORE_PASS}"

if [[ -z "$STORE_PASS" ]]; then
  echo "Set BEBALAP_KEYSTORE_PASSWORD terlebih dahulu." >&2
  exit 1
fi

keytool -genkeypair -v \
  -keystore "$OUT" \
  -alias "$ALIAS" \
  -keyalg RSA \
  -keysize 4096 \
  -validity 10000 \
  -storepass "$STORE_PASS" \
  -keypass "$KEY_PASS" \
  -dname "CN=BeBalap, OU=Android, O=BeBalap, L=Pontianak, ST=Kalimantan Barat, C=ID"

echo
printf 'Keystore dibuat: %s\n' "$OUT"
printf 'Alias: %s\n' "$ALIAS"
printf 'GitHub secret ANDROID_KEYSTORE_BASE64:\n'
base64 -w 0 "$OUT" 2>/dev/null || base64 "$OUT" | tr -d '\n'
echo
