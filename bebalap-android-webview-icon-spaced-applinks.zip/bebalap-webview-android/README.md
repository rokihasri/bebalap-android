# BeBalap Android WebView

Android WebView resmi untuk **BeBalap** (`https://bebalap.thegreatmonolith.com`) dengan package **`app.bebalap.id`**.

## Fitur

- Fullscreen WebView tema putih.
- Splash screen putih + logo BeBalap di tengah selama ±2 detik.
- OneSignal Android SDK native dengan App ID yang sama seperti aplikasi web BeBalap.
- External ID native mengikuti pola server: `bebalap_user_{ID}` sehingga push per-user dapat tetap memakai alias yang sama.
- Klik push membuka URL terkait langsung di WebView BeBalap.
- Small notification icon memakai icon push BeBalap saat ini, bukan icon lonceng default.
- Upload file: file picker, multi-file, kamera foto, video.
- Web camera/WebRTC untuk Camera Race (`getUserMedia`).
- Microphone jika halaman web memintanya.
- Geolocation jika halaman BeBalap memintanya.
- Download file dengan cookie login WebView.
- Deep link `https://bebalap.thegreatmonolith.com/...` masuk ke aplikasi.
- Offline fallback native.
- GitHub Actions untuk Debug APK dan Signed Release APK + AAB.

## Konfigurasi saat ini

- Package: `app.bebalap.id`
- Base URL: `https://bebalap.thegreatmonolith.com`
- OneSignal App ID: `a987ee36-33ba-4b99-a33e-3957118d9274`
- `minSdk`: 23
- `targetSdk`: 36
- `compileSdk`: 36
- Java: 17
- Android Gradle Plugin: 8.13.2
- Gradle CI: 8.13
- OneSignal Android SDK: 5.9.8

## Build otomatis di GitHub

Upload seluruh isi project ini ke repository GitHub.

### Debug APK

Workflow **Build Debug APK** berjalan otomatis pada push ke `main`/`master`, pull request, atau manual dari tab **Actions**.

Hasil ada di:

- Actions → Build Debug APK → Artifacts → `BeBalap-debug-apk`

### Release APK + AAB Play Store

Untuk release signed, buat upload keystore satu kali dan jangan pernah mengganti keystore tersebut setelah aplikasi dipublikasikan.

Contoh Linux/macOS:

```bash
export BEBALAP_KEYSTORE_PASSWORD='PASSWORD_KUAT'
export BEBALAP_KEY_PASSWORD='PASSWORD_KUAT'
export BEBALAP_KEY_ALIAS='bebalap'
./scripts/generate-upload-keystore.sh
```

Simpan file `.jks` dengan aman. Tambahkan 4 GitHub Actions secrets di:

**Repository → Settings → Secrets and variables → Actions**

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Untuk membuat nilai `ANDROID_KEYSTORE_BASE64`:

```bash
base64 -w 0 bebalap-upload.jks
```

Kemudian buka **Actions → Build Signed Release APK + AAB → Run workflow**. Isi version name, misalnya `1.0.0`.

Hasil artifact berisi:

- `app-release.apk`
- `app-release.aab` → file untuk Google Play Console

`versionCode` otomatis memakai `GITHUB_RUN_NUMBER`, sehingga naik pada setiap build GitHub.

## OneSignal: langkah dashboard yang wajib

Project sudah memakai App ID OneSignal milik BeBalap dan kode Android native sudah siap. Namun agar Android benar-benar menerima push, **platform Android/FCM harus diaktifkan pada OneSignal App ID yang sama**.

Di OneSignal:

1. Buka aplikasi OneSignal yang App ID-nya `a987ee36-33ba-4b99-a33e-3957118d9274`.
2. Settings → Push & In-App.
3. Tambahkan/aktifkan **Google Android (FCM)** jika belum ada.
4. Masukkan Firebase/FCM credentials yang diminta OneSignal.
5. Install APK di perangkat fisik dan izinkan notifikasi.
6. Login ke BeBalap. Native OneSignal otomatis melakukan `login("bebalap_user_ID")` agar sesuai dengan target push dari Laravel.

Tidak ada OneSignal REST API Key yang disimpan di APK. API Key rahasia tetap hanya di backend Laravel.

## Perilaku link push

Laravel BeBalap saat ini mengirim `url` pada payload OneSignal. Aplikasi Android membaca `launchURL` tersebut:

- URL domain `bebalap.thegreatmonolith.com` → dibuka di WebView yang sama.
- URL eksternal → dibuka lewat aplikasi/browser yang sesuai.
- Link relatif seperti `/profil` juga dinormalisasi ke domain BeBalap.

## Permission

Manifest sudah memuat permission yang dibutuhkan, tetapi permission sensitif hanya diminta saat diperlukan:

- `POST_NOTIFICATIONS`
- `CAMERA`
- `RECORD_AUDIO`
- `ACCESS_FINE_LOCATION` / `ACCESS_COARSE_LOCATION`
- Legacy `WRITE_EXTERNAL_STORAGE` hanya sampai Android 9 untuk download.

Upload file modern menggunakan Android Storage Access Framework, jadi tidak membutuhkan izin akses seluruh penyimpanan.

## Catatan Camera Race

`getUserMedia()` dari halaman Camera Race diberikan akses kamera hanya jika request berasal dari origin resmi `https://bebalap.thegreatmonolith.com`. Origin lain otomatis ditolak.

Untuk frame rate tinggi (120/240 FPS), kemampuan WebView tetap mengikuti kemampuan Android System WebView dan camera HAL perangkat. Jika Camera Race nanti membutuhkan kontrol FPS yang benar-benar deterministik, modul kamera dapat dinaikkan ke CameraX native tanpa mengganti package atau arsitektur push/deep-link project ini.

## Buka dengan Android Studio

Project ini dapat dibuka langsung dari root folder. Android Studio akan memakai konfigurasi Gradle project. Untuk build lokal, gunakan Gradle 8.13 + JDK 17, atau biarkan Android Studio mengelola Gradle yang kompatibel.

## Verified Android App Links

Manifest memakai `android:autoVerify="true"` untuk `https://bebalap.thegreatmonolith.com/*`.
Agar link web langsung masuk ke aplikasi, server Bebalap harus menyediakan:

`https://bebalap.thegreatmonolith.com/.well-known/assetlinks.json`

File untuk upload key Bebalap disertakan terpisah pada patch website. Jika aplikasi didistribusikan melalui Google Play App Signing, tambahkan juga SHA-256 **App signing certificate** dari Play Console ke `sha256_cert_fingerprints`.
